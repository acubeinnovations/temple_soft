<!--

var CURRENT_URL = '<?php echo $current_url ?>';
-->